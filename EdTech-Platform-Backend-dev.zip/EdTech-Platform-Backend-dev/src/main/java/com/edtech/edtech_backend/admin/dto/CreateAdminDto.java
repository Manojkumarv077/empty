package com.edtech.edtech_backend.admin.dto;

import lombok.Data;

@Data
public class CreateAdminDto {

    private String email;
    private String password;
}
