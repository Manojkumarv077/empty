package com.edtech.edtech_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdtechBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdtechBackendApplication.class, args);
	}

}
