package com.edtech.edtech_backend.common.enums;

public enum QuizStatus {

    IN_PROGRESS,
    COMPLETED

}
