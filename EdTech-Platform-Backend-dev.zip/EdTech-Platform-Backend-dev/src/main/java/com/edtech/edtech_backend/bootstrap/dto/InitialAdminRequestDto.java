package com.edtech.edtech_backend.bootstrap.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InitialAdminRequestDto {

    private String email;
    private String password;
}
