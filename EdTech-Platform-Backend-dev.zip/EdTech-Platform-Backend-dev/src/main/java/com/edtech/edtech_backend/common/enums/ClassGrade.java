package com.edtech.edtech_backend.common.enums;

public enum ClassGrade {

    CLASS_8,
    CLASS_9,
    CLASS_10,
    CLASS_11,
    CLASS_12

}
