package com.edtech.edtech_backend.common.enums;

public enum Role {

    SUPER_ADMIN,
    STUDENT

}
