package com.edtech.edtech_backend.student.dto;

import lombok.Data;

@Data
public class StudentAvatarUploadDto {

    private String avatarUrl;
}
